<?php
/**
 * 功能：权限验证
 * 作者： 李坡
 * 日期：2015年8月7日  *
 */
include_once 'crudCtr.php';

class checkCtr extends crudCtr {
	
	/**
	 * 
	 * 
	 * @param array $result        	
	 */
	public function login() {
		$capturs = $this->captureParams ();
		$newrow = $capturs ['newrow'];
		$telephone = $newrow ['telephone'];
		$pwd = $newrow ['pwd'];
		$type=$newrow['type'];
		$querySql = "select tid,token,user_name,city,login_state from oa_user_info  
		 where  telephone='" . $telephone."'" . " and pwd='" . $pwd."'";
		$model = spClass ( 'oa_user_info' );
		$results = $model->findSql ( $querySql );
		if ($results) {
				return $results;
			}else{
				return false;
			}
		} 
	
	/**
	 * 验证接口的访问权限
	 */
	public function acl() {
		$capturs = $this->captureParams ();
		$token = $capturs ['token'];
		$newrow = $capturs ['newrow'];
		$c = $this->spArgs ( 'c' );
		$a = $this->spArgs ( 'a' );
		$user_tid=$newrow['user_tid'];
		$querySql='select o.city,a.acl_value from oa_user_info o 
							 left join user_roles_info u on o.tid=u.oa_user_info_tid
							 left join roles_acl_info r on u.roles_info_tid=r.roles_info_tid
                             left join acl_info a on a.tid=r.acl_info_tid 
                             where  o.token="'.$token.'"'. 'and o.tid="'.$user_tid.'"'.' and  controller="'.$c.'"'.' and action="'.$a.'"';
		
// 		echo $querySql;
		$model = spClass ( 'oa_user_info' );
		$results = $model->findSql ( $querySql);
	
		if ($results) {
			 
			if (1==$results[0]['acl_value']) {//验证成功后在操作日志表里添加操作记录

				return $results;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	/**
	 * 退出登陆后，清除用户acl的存储信息
	 */
	public function logout() {
		setsession ( md5 ( "acl_info" ), "", time () - 7200 ); /* expire in 2 hour */
	}
	/**
	 * 每操作完成记录操作人信息
	 */
	public function record(){
		$capturs = $this->captureParams ();
		$token = $capturs ['token'];
		$newrow = $capturs ['newrow'];
		$c = $this->spArgs ( 'c' );
		$a = $this->spArgs ( 'a' );
		$user_tid = $newrow ['user_tid'];
		$querySql = 'select o.user_name,o.city,o.telephone ,r.roles_name 
						from oa_user_info o,roles_info r 
						where  r.tid=o.roles_tid and o.tid="' . $user_tid . '"';
		$model = spClass ( 'oa_user_info' );
		$results = $model->findSql ( $querySql );
		if ($results) {
			$new ['user_tid'] = $user_tid;
			$new ['telephone'] = $results [0] ['telephone'];
			$new ['city'] = $results [0] ['city'];
			$new ['user_name'] = $results [0] ['user_name'];
			$new ['controller'] = $c;
			$new ['action'] = $a;
			$new ['roles_name'] = $results [0] ['roles_name'];
			$model = spClass ( 'transaction_log_info' );
			$result = $model->create ( $new );
			if ($result > 0) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	/**
	 * 手动验证用户tid、token是否存在于表table_name中
	 * @param string $tid_name 用户tid的字段名
	 * @param int $tid_value 用户tid的值
	 * @param string $accessToken_name 用户token的字段名
	 * @param string $accessToken_value 用户token的值
	 * @param string $table_name 用户信息存放的数据表
	 * @return 若验证存在，则返回用户信息，否则输出错误提示
	 */
	public function verifyAuth($accessToken_name='',$accessToken_value='',$table_name='') {
		$msg = new responseMsg ();
		$conn = @mysql_connect(mysql_address,mysql_account,mysql_password,0) or die(mysql_error());
		$sql = 'SELECT table_name FROM information_schema.columns WHERE table_name = "'.$table_name.'"';
		$query_result = @mysql_query($sql) or die(" 查找数据表的SQL语句执行失败 ");//执行SQL语句
		if(!$query_result){
			mysql_close ( $conn );
			return false;
		}else{
			$sql = 'SELECT column_name FROM information_schema.columns WHERE table_name = "'.$table_name.'" AND column_name = "'.$accessToken_name.'"';
			$query_result = @mysql_query($sql) or die(" 查找字段名的SQL语句执行失败 ");//执行SQL语句
			if(!$query_result){
				mysql_close ( $conn );
				return false;
			}else{
				$sql = 'SELECT * FROM eteacher.'.$table_name.' WHERE '.$accessToken_name.' = "'.$accessToken_value.'" ';
				$gb = spClass($table_name); // 初始化数据表模型类
				$result = @$gb->findSql($sql); // 执行查找
				if(!$result){
					mysql_close ( $conn );
					return false;
				}else{
					mysql_close ( $conn );
					return $result['0'];
				}
			}
		}
	}
		}
	
	
	
	
	
	
	

