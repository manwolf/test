<?php
/* *
 * 功能：支付宝服务器异步通知页面
 * 版本：3.3
 * 日期：2012-07-23
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。


 *************************页面功能说明*************************
 * 创建该页面文件时，请留心该页面文件中无任何HTML代码及空格。
 * 该页面不能在本机电脑测试，请到服务器上做测试。请确保外部可以访问该页面。
 * 该页面调试工具请使用写文本函数logResult，该函数已被默认关闭，见alipay_notify_class.php中的函数verifyNotify
 * 如果没有收到该页面返回的 success 信息，支付宝会在24小时内按一定的时间策略重发通知
 */

require_once("alipay.config.php");
require_once("lib/alipay_notify.class.php");

//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyNotify();

if($verify_result) {//验证成功
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//请在这里加上商户的业务逻辑程序代

	
	//——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
	
    //获取支付宝的通知返回参数，可参考技术文档中服务器异步通知参数列表
	
	//商户订单号
	$out_trade_no = $_POST['out_trade_no'];
	//交易状态
	$trade_status = $_POST['trade_status'];
	// 买家ID
	$buyer_id = $_POST['buyer_id'];
	// 支付宝流水号
	$trade_no = $_POST['trade_no'];
    if($_POST['trade_status'] == 'TRADE_FINISHED') {
		//判断该笔订单是否在商户网站中已经做过处理
			//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
			//如果有做过处理，不执行商户的业务程序
		//注意：
		//该种交易状态只在两种情况下出现
		//1、开通了普通即时到账，买家付款成功后。
		//2、开通了高级即时到账，从该笔交易成功时间算起，过了签约时的可退款时限（如：三个月以内可退款、一年以内可退款等）后。

        //调试用，写文本函数记录程序运行情况是否正常
        //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
    }
    else if ($_POST['trade_status'] == 'TRADE_SUCCESS') {
		//判断该笔订单是否在商户网站中已经做过处理
			//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
			//如果有做过处理，不执行商户的业务程序
		//注意：
		//该种交易状态只在一种情况下出现——开通了高级即时到账，买家付款成功后。

        //调试用，写文本函数记录程序运行情况是否正常
        //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
    }
	
    
    # 根据out_trade_no，找出order_tid
    $con = mysql_connect("localhost","root","sicai");
    if (!$con)
    {
    	die('Could not connect: ' . mysql_error());
    }
    	
    mysql_select_db("eteacher", $con);
    	
    $result = mysql_query("SELECT order_tid,pay_done,invitation_code FROM pay_list where out_trade_no='".$out_trade_no."'");
    $pay_list_array = mysql_fetch_array($result);
    mysql_close($con);
    # 如果已经支付，则打印success结束所有脚本运行
   	if(1 == $pay_list_array['pay_done']){
   		exit("success");
   	}
   
    $con = mysql_connect("localhost","root","sicai");
    if (!$con)
    {
    	die('Could not connect: ' . mysql_error());
    }
    
    mysql_select_db("eteacher", $con);
    # 完成支付
    $Sql = "update pay_list set ".
    		"trade_no='".$trade_no."',buyer_id='".$buyer_id.
    		"',pay_done= '1' where out_trade_no='".$out_trade_no."' and tid > 0";
    mysql_query($Sql);
    # 根据order_tid取出order_list表中的order_type和order_money
    $result = mysql_query("SELECT order_type, order_money, user_tid, user_spelling_lesson_tid FROM order_list where tid='".$pay_list_array['order_tid']."'");
    $order_list_array = mysql_fetch_array($result);
    mysql_close($con);
    if(2 == $order_list_array['order_type']){
    	# 修改钱包余额
    	$con = mysql_connect("localhost","root","sicai");
    	if (! $con) {
    		die ( 'Could not connect: ' . mysql_error () );
    	}
    	mysql_select_db ( "eteacher", $con );
    	$sqlStr = "update wallet_list set balance = balance+".$order_list_array['order_money']." where tid>0 and user_tid=".$order_list_array['user_tid'];
    	mysql_query ( $sqlStr );
    	mysql_close ( $con );
    }
    
	//——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
    $con = mysql_connect("localhost","root","sicai");
    if (!$con)
    {
    	die('Could not connect: ' . mysql_error());
    }
    mysql_select_db("eteacher", $con);
    if ($pay_list_array['invitation_code']) {
    	// 根据折扣率，计算出最终价格
    	$order_tid = $pay_list_array['order_tid'];
    	$invitation_code = $pay_list_array['invitation_code'];
    	// 根据user_tid，找到user所在城市  $order_list_array["user_tid"], $newrow ['invitation_code']
    	// 然后调用类SCInvitationCtr中的askInvitation接口，查询折扣率
    	// 最后用订单价格 乘以 折扣率，计算出发起请求的价格
    	# 根据订单tid, 查询出 订单价格（order_money）、用户所在城市（user_city）
    	$query = "select o.order_money, u.user_city ".
    			"from order_list o, user_info u where o.user_tid = u.tid and o.tid = {$order_tid};";
    	$query_array = mysql_fetch_array(mysql_query($query));
    	if(!$query_array)
    		exit( $prefixJS . "({\"code\":1,\"msg\":\"用户城市查询失败或订单价格失败！\",\"data\":[{}],\"pages\":1})" );
    	$url = "http://{$_SERVER['HTTP_HOST']}/srvapi/framework/index.php?c=SCInvitationCtr&a=askInvitation".
    			"&invitation_code={$invitation_code}&city={$query_array["user_city"]}";
    	$response = file_get_contents ( $url );
    	$invitation_discount_array = json_decode ( substr ( $response, 1, strlen ( $response ) - 2 ) );
    	$invitation_discount = $invitation_discount_array->data [0]->invitation_discount;
    	$price = $order_list_array['order_money'] * $invitation_discount;
    	// 修改订单价格
    	$updateorderList = "update order_list set order_money = {$price} where tid= {$order_tid}";
    	if( !mysql_query($updateorderList) )
    		exit( $prefixJS . "({\"code\":1,\"msg\":\"修改订单价格失败！\",\"data\":[{}],\"pages\":1})" );
    	// 调用邀请码插入记录接口
    	$url = "http://{$_SERVER['HTTP_HOST']}/srvapi/framework/index.php?c=SCInvitationCtr&a=recordInvitationUse&invitation_code=" . $invitation_code . "&order_tid=" . $order_tid;
    	file_get_contents ( $url );
    }
    # 判断该学生支付订单是否是拼课订单
    # 如果是拼课订单，则做相应处理
    if ($order_list_array['user_spelling_lesson_tid']) { // 若有拼课订单
    	// 查询拼课信息中的支付人数和参与者的人数
    	$querySql = "select count(o.pay_done) as pay_number,u.participants_number ".
    			"from user_spelling_lesson u,order_list o where u.tid=o.user_spelling_lesson_tid ".
    			"and o.pay_done=1 and  u.tid=\"{$order_list_array['user_spelling_lesson_tid']}\"";
    	$count_array = mysql_fetch_array(mysql_query($querySql));
    	if(!$count_array)
    		exit( $prefixJS . "({\"code\":1,\"msg\":\"订单表查询失败！\",\"data\":[{}],\"pages\":1})" );
    	# 支付人数与参与人数相同的话，则改拼课订单支付成功
    	if ($count_array['pay_number'] == $count_array['participants_number']){
    		# 当所有人支付完成后,拼课订单改为已支付（set pay_done=1）
    		$updateSql = "update user_spelling_lesson set pay_done=1 where tid=\"{$order_list_array['user_spelling_lesson_tid']}\"";
    		if( !mysql_query($updateSql) )
    			exit( $prefixJS . "({\"code\":1,\"msg\":\"拼课订单支付状态修改失败！\",\"data\":[{}],\"pages\":1})" );
    		# 每人只能参与一个拼客,当支付之后,又可以发起或参与新的拼客(开发中)
    		// 				$update='update user_info set spelling_class_state=0 where tid='.$user_tid;
    		// 				if( !mysql_query($update) )
    		// 					exit( $prefixJS . "({\"code\":1,\"msg\":\"修改用户拼课状态失败！\",\"data\":[{}],\"pages\":1})" );
    	}
    }
    mysql_close($con);
	echo "success";		//请不要修改或删除
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
else {
    //验证失败
    echo "fail";

    //调试用，写文本函数记录程序运行情况是否正常
    //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
}
?>