<?php
$loader = include __DIR__ . '/../vendor/autoload.php';
$loader->add('JPush', __DIR__ . '/../src');