<?php
ini_set('date.timezone','Asia/Shanghai');
error_reporting(E_ERROR);

require_once "../lib/WxPay.Api.php";
require_once '../lib/WxPay.Notify.php';
require_once 'log.php';

//初始化日志
$logHandler= new CLogFileHandler("/home/log/log_notify1.txt".date('Y-m-d').'.log');
$log = Log::Init($logHandler, 15);

class PayNotifyCallBack extends WxPayNotify
{
	//查询订单
	public function Queryorder($transaction_id)
	{
		$input = new WxPayOrderQuery();
		$input->SetTransaction_id($transaction_id);
		$result = WxPayApi::orderQuery($input);
		Log::DEBUG("query:" . json_encode($result));
		if(array_key_exists("return_code", $result)
			&& array_key_exists("result_code", $result)
			&& $result["return_code"] == "SUCCESS"
			&& $result["result_code"] == "SUCCESS")
		{				
			# 根据out_trade_no，找出order_tid
			$con = mysql_connect("localhost","root","sicai");
			if (!$con)
			{
				die('Could not connect: ' . mysql_error());
			}
			 
			mysql_select_db("eteacher", $con);
			
			$pay_list_array = mysql_query("SELECT order_tid,pay_done,invitation_code FROM pay_list where out_trade_no='".$result['out_trade_no']."'");
			$pay_list_array = mysql_fetch_array($pay_list_array);
			mysql_close($con);
			# 如果订单已经被pay_done,则return ture
			if(1 == $pay_list_array['pay_done']){
				return true;
			}
			# 根据order_tid取出order_list表中的order_type和order_money
			$con = mysql_connect("localhost","root","sicai");
			if (!$con)
			{
				die('Could not connect: ' . mysql_error());
			}
			
			mysql_select_db("eteacher", $con);
			# 完成支付
			$Sql = "update pay_list set ".
					"trade_no='".$result['transaction_id']."',buyer_id='".$result['openid'].
					"',pay_done= '1' where out_trade_no='".$result['out_trade_no']."' and tid > 0";
			mysql_query($Sql);
			#查询order_list表中 的order_type, order_money, user_tid, user_spelling_lesson_tid
			$order_list_array = mysql_query("SELECT order_type, order_money, user_tid, user_spelling_lesson_tid FROM order_list where tid='".$pay_list_array['order_tid']."'");
			$order_list_array = mysql_fetch_array($order_list_array);
			mysql_close($con);			
			
			if(2 == $order_list_array['order_type']){
				# 修改钱包余额
				$con = mysql_connect("localhost","root","sicai");
				if (! $con) {
					die ( 'Could not connect: ' . mysql_error () );
				}
			
				mysql_select_db ( "eteacher", $con );
			
				$sqlStr = "update wallet_list set balance = balance+".$order_list_array['order_money']." where tid>0 and user_tid=".$order_list_array['user_tid'];
				
				mysql_query ( $sqlStr );
				mysql_close ( $con );
			}
			
			//——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
			$con = mysql_connect("localhost","root","sicai");
			if (!$con)
			{
				die('Could not connect: ' . mysql_error());
			}
			mysql_select_db("eteacher", $con);
			if ($pay_list_array['invitation_code']) {
				// 根据折扣率，计算出最终价格
				$order_tid = $pay_list_array['order_tid'];
				$invitation_code = $pay_list_array['invitation_code'];
				// 根据user_tid，找到user所在城市  $order_list_array["user_tid"], $newrow ['invitation_code']
				// 然后调用类SCInvitationCtr中的askInvitation接口，查询折扣率
				// 最后用订单价格 乘以 折扣率，计算出发起请求的价格
				# 根据订单tid, 查询出 订单价格（order_money）、用户所在城市（user_city）
				$query = "select  u.user_city ".
						"from order_list o, user_info u where o.user_tid = u.tid and o.tid = {$order_tid};";
				$query_array = mysql_fetch_array(mysql_query($query));
				if(!$query_array)
					exit( $prefixJS . "({\"code\":1,\"msg\":\"用户城市查询失败或订单价格失败！\",\"data\":[{}],\"pages\":1})" );
				$url = "http://{$_SERVER['HTTP_HOST']}/srvapi/framework/index.php?c=SCInvitationCtr&a=askInvitation".
						"&invitation_code={$invitation_code}&city={$query_array["user_city"]}";
				$response = file_get_contents ( $url );
				$invitation_discount_array = json_decode ( substr ( $response, 1, strlen ( $response ) - 2 ) );
				$invitation_discount = $invitation_discount_array->data [0]->invitation_discount;
				$price = $order_list_array['order_money'] * $invitation_discount;
				// 修改订单价格
				$updateorderList = "update order_list set order_money = {$price} where tid= {$order_tid}";
				if( !mysql_query($updateorderList) )
					exit( $prefixJS . "({\"code\":1,\"msg\":\"修改订单价格失败！\",\"data\":[{}],\"pages\":1})" );
				// 调用邀请码插入记录接口
				$url = "http://{$_SERVER['HTTP_HOST']}/srvapi/framework/index.php?c=SCInvitationCtr&a=recordInvitationUse&invitation_code=" . $invitation_code . "&order_tid=" . $order_tid;
				file_get_contents ( $url );
			}		
			# 判断该学生支付订单是否是拼课订单
			# 如果是拼课订单，则做相应处理
			if ($order_list_array['user_spelling_lesson_tid']) { // 若有拼课订单
				// 查询拼课信息中的支付人数和参与者的人数
				$querySql = "select count(o.pay_done) as pay_number,u.participants_number ".
						"from user_spelling_lesson u,order_list o where u.tid=o.user_spelling_lesson_tid ".
						"and o.pay_done=1 and  u.tid=\"{$order_list_array['user_spelling_lesson_tid']}\"";
				$count_array = mysql_fetch_array(mysql_query($querySql));
				if(!$count_array)
					exit( $prefixJS . "({\"code\":1,\"msg\":\"订单表查询失败！\",\"data\":[{}],\"pages\":1})" );
				# 支付人数与参与人数相同的话，则改拼课订单支付成功
				if ($count_array['pay_number'] == $count_array['participants_number']){
					# 当所有人支付完成后,拼课订单改为已支付（set pay_done=1）
					$updateSql = "update user_spelling_lesson set pay_done=1 where tid=\"{$order_list_array['user_spelling_lesson_tid']}\"";
					if( !mysql_query($updateSql) )
						exit( $prefixJS . "({\"code\":1,\"msg\":\"拼课订单支付状态修改失败！\",\"data\":[{}],\"pages\":1})" );
						# 每人只能参与一个拼客,当支付之后,又可以发起或参与新的拼客(开发中)
						// 				$update='update user_info set spelling_class_state=0 where tid='.$user_tid;
						// 				if( !mysql_query($update) )
							// 					exit( $prefixJS . "({\"code\":1,\"msg\":\"修改用户拼课状态失败！\",\"data\":[{}],\"pages\":1})" );
					}
			}				
			mysql_close($con);
			
			return true;
		}
		return false;
	}
	
	//重写回调处理函数
	public function NotifyProcess($data, &$msg)
	{
		Log::DEBUG("call back:" . json_encode($data));
		$notfiyOutput = array();
		
		if(!array_key_exists("transaction_id", $data)){
			$msg = "输入参数不正确";
			return false;
		}
		//查询订单，判断订单真实性
		if(!$this->Queryorder($data["transaction_id"])){
			$msg = "订单查询失败";
			return false;
		}
		return true;
	}
}

Log::DEBUG("begin notify");
$notify = new PayNotifyCallBack();
$notify->Handle(false);
