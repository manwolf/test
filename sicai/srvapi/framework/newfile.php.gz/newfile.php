<?php

$start = date ( "Y-m-d H:i:s", mktime ( 0, 0, 0, date ( "m" ), date ( "d" ), date ( "Y" ) ) );
$end = date ( "Y-m-d H:i:s", mktime ( 23, 59, 59, date ( "m" ), date ( "d" ), date ( "Y" ) ) );
// 获取本周的起始时间和结束时间
$startweek = date ( "Y-m-d H:i:s", mktime ( 0, 0, 0, date ( "m" ), date ( "d" ) - date ( "w" ) + 1 , date ( "Y" ) ) );
$endweek = date ( "Y-m-d H:i:s", mktime ( 23, 59, 59, date ( "m" ), date ( "d" ) - date ( "w" ) + 7 , date ( "Y" ) ) );
// 获取本月的起始时间和结束时间
$beginThismonth = date ( "Y-m-d H:i:s", mktime ( 0, 0, 0, date ( 'm' ), 1, date ( 'Y' ) ) );
$endThismonth = date ( "Y-m-d H:i:s", mktime ( 23, 59, 59, date ( 'm' ), date ( 't' ), date ( 'Y' ) ) );
echo $start."</ br>";
echo $end."</ br>";
echo $startweek."</ br>";
echo $endweek."</ br>";
echo $beginThismonth."</ br>";
echo $endThismonth."</ br>";
