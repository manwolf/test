<?php
header ( "Content-Type: text/html; charset=UTF-8" );
header ( "Access-Control-Allow-Origin:*" );
/* clearstatcache();
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . "GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); */
/* $str = $_REQUEST['str'];
echo $str;
echo "</br >---------";
echo strlen($str);
echo "</br >utf8_decode---------";
echo strlen(utf8_decode($str));
echo "</br >---------";
echo mb_strlen($str);
echo "</br >8bit---------";
echo mb_strlen($str,'8bit');
echo "</br >iconv_strlen---------";
echo iconv_strlen($str,"UTF-8"); //返回5.iconv_strlen 是统计字符串的字符数量
echo "</br >自定义函数--------";
echo mb_strlen($str,'8bit'); */

// 判断文件上传是否发生意外错误
if ($_FILES == NULL or $_FILES ["file"] ["error"] > 0) {
	echo json_encode ( array (
			"code" => 1,
			"msg" => ' 上传文件出错' . $_FILES ["file"] ["error"],
			"data" => $_FILES,
			"pages" => 0
	) );
	exit ();
	break;
}
$callback = $_POST ['callback']; // JS_Callback
print_r($_FILES);

 echo "</br >---------";
/* echo "</br >当前文件目录".getcwd(); */
$file = $_FILES ['file'] ['tmp_name'];

/* echo "</br >当前文件为：".$file;
$file_path = dirname(path);
echo "</br >该文件路径为：".$file_path;
$file_name = basename($file_path);
echo "</br >该文件名为：".$file_name;
//改变 目录
chdir($file_path);
echo "</br >新当前文件目录".getcwd();
  */
if (file_exists ( $file )) {
	$md5_hash = md5_file($file);
	if($md5_hash == false){
		echo "</br >文件加密失败";
	}else{
		print '</br > MD5加密 16位: ' . md5_file($file,true);
		print '</br > MD5加密 32位: ' . md5_file($file,false);
	}
}else{
	echo "</br >文件不存在";
}

// 计算中文字符串长度
function utf8_strlen($string = null) {
	// 将字符串分解为单元
	preg_match_all("/./us", $string, $match);
	// 返回单元个数
	return count($match[0]);
}

?>
