<?php
class high_quality_class_way extends spModel
{

	var $pk = "tid"; // 每个留言唯一的标志，可以称为主键

	var $table = "high_quality_class_way"; // 数据表的名称
}