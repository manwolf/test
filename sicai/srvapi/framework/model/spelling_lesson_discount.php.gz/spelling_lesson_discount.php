
<?php
class spelling_lesson_discount extends spModel
{

	var $pk = "tid"; // 唯一的标志，可以称为主键

	var $table = "spelling_lesson_discount"; // 数据表的名称
}