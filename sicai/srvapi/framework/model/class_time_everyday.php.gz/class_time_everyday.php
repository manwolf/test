<?php

class class_time_everyday extends spModel
{

    var $pk = "tid"; // 每个留言唯一的标志，可以称为主键

    var $table = "class_time_everyday"; // 数据表的名称
}