<?php
class container_info extends spModel
{

	var $pk = "tid"; // 每个唯一的标志，可以称为主键

	var $table = "container_info"; // 数据表的名称
}