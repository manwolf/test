<?php

class roles_acl_info extends spModel

{
  var $pk = "tid";
  var $table = "roles_acl_info";
  

}
	