<?php

class class_grade_list extends spModel
{

    var $pk = "tid"; // 每个留言唯一的标志，可以称为主键

    var $table = "class_grade_list"; // 数据表的名称
}