<?php
class acl_info extends spModel
{

	var $pk = "tid"; // 每个留言唯一的标志，可以称为主键

	var $table = "acl_info"; // 数据表的名称
	
	var $linker = array(
			array(
					'type' => 'hasmany',   // 一对多关联
					'map' => 'roles_acl_info',    // 关联的标识
					'mapkey' => 'tid',
					'fclass' => 'roles_acl_info',
					'fkey' => 'acl_info_tid',
					'enabled' => true
			),
	);
	

	
	
}