<?php
class transaction_log_info extends spModel
{

	var $pk = "tid"; // 每个留言唯一的标志，可以称为主键

	var $table = "transaction_log_info"; // 数据表的名称
}